//
//  SmartphoneApp.swift
//  SmartphoneApp


//

import SwiftUI

@main
struct SmartphoneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
